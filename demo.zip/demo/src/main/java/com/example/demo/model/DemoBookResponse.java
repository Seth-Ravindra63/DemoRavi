package com.example.demo.model;

public class DemoBookResponse {

	private String demobookstatusresponse;

	public String getDemobookstatusresponse() {
		return demobookstatusresponse;
	}

	public void setDemobookstatusresponse(String demobookstatusresponse) {
		this.demobookstatusresponse = demobookstatusresponse;
	}
	
}

