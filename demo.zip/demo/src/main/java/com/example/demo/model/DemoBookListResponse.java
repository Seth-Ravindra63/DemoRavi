package com.example.demo.model;

import java.util.List;

public class DemoBookListResponse {
private List<DemoBook> demoBooks;

public List<DemoBook> getDemoBook() {
	return demoBooks;
}

public void setDemoBook(List<DemoBook> demoBooks) {
	this.demoBooks = demoBooks;
}




}
